﻿using VendingMachineLogic;

var chc = new CoinHandlingConsole();
chc.HandleCoins();